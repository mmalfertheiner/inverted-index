inverted-index
==============

Inverted index project for Information Retrieval course

installation on CentOS 6.4
--------------------------

sudo yum install python-devel python-nose python-setuptools gcc gcc-gfortran gcc-c++ blas-devel lapack-devel atlas-devel
pip3 install numpy
pip3 install nltk
pip3 install scipy
pip3 install scikit-learn


Create folder books and storage
